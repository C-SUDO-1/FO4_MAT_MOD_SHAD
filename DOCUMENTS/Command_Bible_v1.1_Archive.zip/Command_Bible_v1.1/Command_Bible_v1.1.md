
# Fallout 4 Shader Permutation Architecture System
## Command & Pipeline Reference – v1.1
Architecture Stabilization + Live Pipeline Edition

---

# 1. Schema Definitions

## perm_table.json
```json
{
  "schema_version": "1.x",
  "perms": [
    {
      "perm_id": "sha1",
      "block_type": "BSLightingShaderProperty",
      "shader_type": 0,
      "spf1": 2151678465,
      "spf2": 1
    }
  ]
}
```

## shader_table.json
```json
{
  "schema_version": "1.x",
  "shaders": [
    {
      "shader_id": "sha1",
      "shader_name": "ExampleShader",
      "structural_signature": "hash"
    }
  ]
}
```

## session_table.json
Tracks ShaderDB session mappings.

## perm_shader_observations.jsonl
```json
{"perm_id":"sha1","shader_id":"sha1","source":"runtime","timestamp":"ISO8601"}
```

---

# 2. Command Argument Tables

## normalize
| Argument | Required | Description |
|----------|----------|------------|
| --permCsv | Yes | Permutation CSV |
| --shaderDb | No | FO4ShaderDB directory |
| --out | Yes | radb_out directory |

## cluster
| Argument | Required | Description |
|----------|----------|------------|
| --in | Yes | radb_out |
| --out | Yes | radb_out |

## link
| Argument | Required | Description |
|----------|----------|------------|
| --in | Yes | radb_out |
| --out | Yes | radb_out |

## link-materials
| Argument | Required | Description |
|----------|----------|------------|
| --in | Yes | radb_out |
| --mapCsv | Yes | Normalized NIF material map |
| --out | Yes | radb_out |

---

# 3. Live Observation Schema

Each JSONL line must contain:
- perm_id
- shader_id
- source
- timestamp

Optional:
- session_id
- build_id
- runtime_context

---

# 4. Architectural Data Flow

```
MaterialCli  → materials_scan.json
NifCli       → mesh_dump_textures.jsonl
Transform    → nif_material_permutation_map.normalized.csv
Normalize    → perm_table / shader_table / session_table
Cluster      → structural_clusters.json
Link         → perm_shader_links.json
Link-Materials → perm_material_links.json
Export       → CSV outputs
```

---

# 5. Permutation Hash Specification

perm_id = SHA1(
  block_type + "|" +
  shader_type + "|" +
  spf1 + "|" +
  spf2
)

All numeric fields must be canonicalized before hashing.

---

# 6. Disaster Recovery Guide

Full rebuild steps:

1. Delete radb_out
2. Re-run MaterialCli scan
3. Re-run NifCli dump
4. Rebuild material map CSV
5. normalize
6. cluster
7. link
8. link-materials
9. export

---

# 7. Contribution Guidelines

- Never change hash inputs without version bump
- Maintain schema_version on JSON outputs
- All new commands must update this document
- Any breaking change requires v2.0 designation

---

# Version Notes

v1.1 expands v1.0 with schema contracts, live ingestion definitions, and rebuild guarantees.
