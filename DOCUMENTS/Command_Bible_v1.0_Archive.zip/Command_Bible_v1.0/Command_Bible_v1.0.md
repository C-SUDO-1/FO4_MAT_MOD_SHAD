
# Fallout 4 Shader Permutation Architecture System
## Command & Pipeline Reference
**Version: 1.0 – Architecture Stabilization Milestone**

---

# System Overview

This system consists of three primary tools:

| Tool | Purpose |
|------|---------|
| MaterialCli | Crawl BGSM/BGEM materials |
| NifCli | Crawl meshes and extract shader + texture signatures |
| RenderArchitectureDB | Normalize, cluster, correlate and export permutation relationships |

---

# Directory Structure Assumptions

```
Material-Editor-master/
├── MaterialCli/
├── NifCli/
├── RenderArchitectureDB/
│   ├── src/RenderArchitectureDB/
│   └── radb_out/
└── FO4ShaderDB/ (optional)
```

---

# MaterialCli

## Scan Materials

```powershell
dotnet .\bin\Release\net8.0\MaterialCli.dll scan `
  --root "<Fallout4DataMaterials>" `
  --out ".\analysis_out\materials_scan.json" `
  --threads 12 `
  --textures
```

Output:
```
analysis_out/materials_scan.json
```

---

# NifCli

## Dump Mesh Shader Blocks + Textures

```powershell
dotnet build -c Release

dotnet .\bin\Release\net8.0\NifCli.dll dump `
  --root "<Fallout4DataMeshes>" `
  --out ".\analysis_out\mesh_dump_textures.jsonl" `
  --include-textures `
  --progress 1000
```

Output:
```
analysis_out/mesh_dump_textures.jsonl
```

---

# RenderArchitectureDB

All commands can be run from:

```
RenderArchitectureDB/src/RenderArchitectureDB
```

---

## Normalize

Perm-only mode:

```powershell
dotnet run -- normalize `
  --permCsv <permCsvPath> `
  --out <radb_out>
```

Full mode (with ShaderDB):

```powershell
dotnet run -- normalize `
  --permCsv <permCsvPath> `
  --shaderDb <FO4ShaderDB> `
  --out <radb_out>
```

Outputs:
```
radb_out/normalized/
  perm_table.json
  shader_table.json
  session_table.json
```

---

## Cluster

```powershell
dotnet run -- cluster --in <radb_out> --out <radb_out>
```

Output:
```
normalized/structural_clusters.json
```

---

## Link (Permutation ↔ Shader)

```powershell
dotnet run -- link --in <radb_out> --out <radb_out>
```

Requires:
```
radb_out/correlation/perm_shader_observations.jsonl
```

Outputs:
```
exports/perm_shader_links.csv
```

---

## Link-Materials

```powershell
dotnet run -- link-materials `
  --in <radb_out> `
  --mapCsv <nif_material_permutation_map.normalized.csv> `
  --out <radb_out>
```

Outputs:
```
exports/perm_material_links.csv
```

---

## Export

```powershell
dotnet run -- export --in <radb_out> --out <radb_out>
```

---

# Full Offline Rebuild Pipeline

1. MaterialCli scan
2. NifCli dump
3. Build nif_material_permutation_map.normalized.csv
4. Normalize
5. Cluster
6. Link
7. Link-materials
8. Export

---

# Live Mode Workflow

Append/update:

```
radb_out/correlation/perm_shader_observations.jsonl
```

Then run:

```powershell
dotnet run -- link --in <radb_out> --out <radb_out>
dotnet run -- export --in <radb_out> --out <radb_out>
```

---

# Version Notes

This document reflects the stabilized command architecture as of v1.0.
